﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("usercategories",Schema ="public")]
    public class UsercategoriesClass
    {
        [Key]

        public int usercategoryid { get; set; }

        public string usercategory { get; set; }
        public string transaction { get; set; }
        public string bankbranch { get; set; }
        public string collections { get; set; }
        public string systemaudit { get; set; }
        public string report { get; set; }
        public string users { get; set; }
        public string feesetup { get; set; }
        public string institution { get; set; }
        public int categoryid { get; set; }
        public string inheritsfrom { get; set; }
        

    }
}
