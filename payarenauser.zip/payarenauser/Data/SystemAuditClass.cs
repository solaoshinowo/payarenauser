﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("systemaudit",Schema ="public")]
    public class systemauditClass
    {
        [Key]

        public int sysauditid { get; set; }

        public string useremail { get; set; }
        public string syslocation { get; set; }

        public string activitytype { get; set; }
        public string statebefore { get; set; }

        public string stateafter { get; set; }
        public string bankcode { get; set; }

        public string bankbranchcode { get; set; }
        public string billercode { get; set; }




    }
}
