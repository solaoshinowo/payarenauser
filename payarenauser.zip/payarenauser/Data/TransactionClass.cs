﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("transaction",Schema = "public")]
    public class transactionClass
    {
        [Key]

        public int transid { get; set; }

        public string collections { get; set; }
        public string vendor { get; set; }
        public string itemnos { get; set; }

        public string trannos { get; set; }
        public string customername { get; set; }
        public string apptype { get; set; }


        public decimal transactionamount { get; set; }

        public string fullrem { get; set; }
        public string responsecode { get; set; }
        public string approvalcode { get; set; }

        public string bankname { get; set; }

        public string branchname { get; set; }
        public string accountnos { get; set; }
        public string accountnamebank { get; set; }

        public string productacct { get; set; }

        public string productname { get; set; }
        public string clerkid { get; set; }
        public string trancurrency { get; set; }

        public string paymentstatus { get; set; }

        public string referencenos { get; set; }
        public string bankteller { get; set; }
        public string depositnos { get; set; }

        public string receiptnos { get; set; }

        public string paymentmode { get; set; }
        public decimal fee { get; set; }
        public decimal totalamount { get; set; }


    }
}
