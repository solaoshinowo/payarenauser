﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using Payarenauser.Services;

namespace Payarenauser.Data
{
    [Table("users",Schema ="public")]
    public class UserClass
    {
        [Key]

        public int userid { get; set; }

        public string username { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public string category { get; set; }
        public string phonenumber { get; set; }

        public string bank { get; set; }
        public string bankbranch { get; set; }

        public string password { get; set; }

        public string passwordconfirmed { get; set; }
        public bool defaultpasswordchanged { get; set; }

         
        

        public List<UsercategoriesClass> categories { get; set; } = new List<UsercategoriesClass>();
        public int categoryid { get; set; }
    }
}
