﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("bank",Schema = "public")]
    public class BankClass
    {
        [Key]

        public int bankid { get; set; }

        public string bankcode { get; set; }
        public string bankabbr { get; set; }
        public string bankfullname { get; set; }
        
    }
}
