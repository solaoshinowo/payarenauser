﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("receipt", Schema = "public")]
    public class receiptClass
    {
        [Key]

        public int receiptid { get; set; }

        public string receiptnos { get; set; }
        public DateTime receiptdate { get; set; }
        public string customername { get; set; }

        public string phonenumber { get; set; }
        public string vendor { get; set; }
        public string collections { get; set; }


        public decimal transactionamount { get; set; }

        public decimal fee { get; set; }
        public decimal totalamount { get; set; }
        public string institution { get; set; }

        public string teller { get; set; }



    }
}
