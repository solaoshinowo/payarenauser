﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("bankbranch",Schema = "public")]
    public class BankBranchClass
    {
        [Key]

        public int bankbranchid { get; set; }

        public string bankbranchcode { get; set; }
        public string bankabbr { get; set; }
        public string bankbranch { get; set; }

        public string bank { get; set; }

    }
}
