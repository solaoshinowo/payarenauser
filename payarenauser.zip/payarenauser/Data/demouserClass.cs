﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;


namespace payarenauser.Data
{
    [Table("demouser", Schema = "public")]
    public class demouser
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Creation { get; set; }
        public string Company { get; set; }

        public string Role { get; set; }

    }
}