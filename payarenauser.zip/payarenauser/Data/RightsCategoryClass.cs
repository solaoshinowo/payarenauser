﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("rightscategory",Schema ="public")]
    public class rightscategoryClass
    {
        [Key]

        public int rightcategoryid { get; set; }

        public string right { get; set; }
        public string description { get; set; }

        
    }
}
