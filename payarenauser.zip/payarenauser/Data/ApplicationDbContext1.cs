﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Payarenauser.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace payarenauser.Data
{
    public class ApplicationDbContext1 : DbContext
    {
        public ApplicationDbContext1(DbContextOptions<ApplicationDbContext1> options)
            : base(options)
        {

        }
        public DbSet<BankClass> Bank { get; set; }
        public DbSet<UserClass> Users { get; set; }

        public DbSet<BankBranchClass> bankbranch { get; set; }

        public DbSet<bankcollectionClass> bankcollection { get; set; }

        public DbSet<receiptClass> receipt { get; set; }

        public DbSet<EmailClass> email { get; set; }

        public DbSet<rightscategoryClass> rightscategory { get; set; }

        public DbSet<systemauditClass> systemaudit { get; set; }

        public DbSet<transactionClass> transaction { get; set; }

        public DbSet<UsercategoriesClass> usercategories { get; set; }

        public DbSet<VendorClass> vendor { get; set; }

        public DbSet<demouser> demouser { get; set; }

        public DbSet<CollectionClass> collection { get; set; }

    }
}
