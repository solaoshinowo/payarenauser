﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("collections", Schema = "public")]
    public class CollectionClass
    {
        [Key]

        public int collectionid { get; set; }

        public string collectioncode { get; set; }
        public string vendor { get; set; }
        public string details { get; set; }


    }
}
