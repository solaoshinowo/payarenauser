﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("bankcollection", Schema = "public")]
    public class bankcollectionClass
    {
        [Key]

        public int collectionid { get; set; }

        public string bank { get; set; }
        public string bankbranch { get; set; }
        public string collectiontype { get; set; }


        public string collectioncode { get; set; }
        public string status { get; set; }
        public string accountno { get; set; }

        public string vendor { get; set; }


    }
}
