﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("vendor", Schema = "public")]
    public class VendorClass
    {
        [Key]

        public int vendorid { get; set; }

        public string vendorcode { get; set; }
        public string vendor { get; set; }
       
        
        



    }
}
