﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payarenauser.Data
{
    [Table("email", Schema = "public")]
    public class EmailClass
    {
        [Key]

        public int emailid { get; set; }

        public string subject { get; set; }
        public string salutation { get; set; }
        public string firstparagraph { get; set; }

        public string secondparagraph { get; set; }

    }
}
