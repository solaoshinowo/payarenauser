﻿function Print() {
    $(".hidewhenprint").hide();
    window.print();
    $(".hidewhenprint").show();
}