﻿<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js", type="text/javascript">
    function Export() {
        $("#table").table2excel({
            filename: "file.xls"
        });
  }
</script>