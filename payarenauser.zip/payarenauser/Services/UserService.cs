﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class UserService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public UserService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<UserClass> GetAllUsers()
           
        {
            return _dbcontext1.Users.ToList();
           
        }

       
        public bool InsertRec(UserClass ucadd)
        {
            _dbcontext1.Users.Add(ucadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public UserClass EdittRec(int userid)
        {
            UserClass uc = new UserClass();

            return _dbcontext1.Users.FirstOrDefault(u=>u.userid==userid);
            
        }
        public bool UpdateRec(UserClass ucupdate)
        {
            var userrecupdate= _dbcontext1.Users.FirstOrDefault(u => u.userid == ucupdate.userid);
            if (userrecupdate != null)
            {
                userrecupdate.firstname = userrecupdate.firstname;
                userrecupdate.lastname = userrecupdate.lastname;
                userrecupdate.email = userrecupdate.email;
                userrecupdate.bank = userrecupdate.bank;
                userrecupdate.bankbranch = userrecupdate.bankbranch;
                userrecupdate.phonenumber = userrecupdate.phonenumber;
                userrecupdate.category = userrecupdate.category;
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(UserClass ucdel)
        {
            var userrecdel = _dbcontext1.Users.FirstOrDefault(u => u.userid == ucdel.userid);
            if (userrecdel != null)
            {
                userrecdel.firstname = userrecdel.firstname;
                userrecdel.lastname = userrecdel.lastname;
                userrecdel.email = userrecdel.email;
                userrecdel.bank = userrecdel.bank;
                userrecdel.bankbranch = userrecdel.bankbranch;
                userrecdel.phonenumber = userrecdel.phonenumber;
                userrecdel.category = userrecdel.category;
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
