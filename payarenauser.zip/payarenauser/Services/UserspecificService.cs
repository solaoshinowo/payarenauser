﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class UserspecificService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public UserspecificService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<UserClass> GetAllUser(string password, string email)
        {

            return _dbcontext1.Users.Where(x => x.password ==password && x.email == email).ToList();
            
        }


        public bool InsertRec(UserClass ubadd)
        {
            _dbcontext1.Users.Add(ubadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public UserClass EdittRec(string useremail)
        {
            UserClass ub = new UserClass();

            return _dbcontext1.Users.FirstOrDefault(u=>u.email== useremail);
            
        }
        public bool UpdateRec(UserClass ubupdate)
        {
            var userrecupdate= _dbcontext1.Users.FirstOrDefault(u => u.email == ubupdate.email);
            if (userrecupdate != null)
            {
                userrecupdate.password = userrecupdate.password;
                userrecupdate.passwordconfirmed = userrecupdate.passwordconfirmed;
               
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(UserClass ubdel)
        {
            var userrecdel = _dbcontext1.Users.FirstOrDefault(u => u.email == ubdel.email);
            if (userrecdel != null)
            {
                userrecdel.password = userrecdel.password;
                userrecdel.passwordconfirmed = userrecdel.passwordconfirmed;
                
                
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
