﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class VendorService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public VendorService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<VendorClass> GetAllvendors()
        {
            return _dbcontext1.vendor.ToList();
        }
        public bool InsertRec(VendorClass ubadd)
        {
            _dbcontext1.vendor.Add(ubadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public VendorClass EdittRec(int vendorid)
        {
            VendorClass ub = new VendorClass();

            return _dbcontext1.vendor.FirstOrDefault(u=>u.vendorid==vendorid);
            
        }
        public bool UpdateRec(VendorClass ubupdate)
        {
            var vendorrecupdate= _dbcontext1.vendor.FirstOrDefault(u => u.vendorid == ubupdate.vendorid);
            if (vendorrecupdate != null)
            {
                vendorrecupdate.vendorcode = vendorrecupdate.vendorcode;
                vendorrecupdate.vendor = vendorrecupdate.vendor;
                
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(VendorClass ubdel)
        {
            var vendorrecdel = _dbcontext1.vendor.FirstOrDefault(u => u.vendorid == ubdel.vendorid);
            if (vendorrecdel != null)
            {
                vendorrecdel.vendorcode = vendorrecdel.vendorcode;
                vendorrecdel.vendor = vendorrecdel.vendor;
                
                
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
