﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class DemouserService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public DemouserService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<demouser> GetAllBanks()
        {
            return _dbcontext1.demouser.ToList();
        }
        public bool InsertRec(demouser ubadd)
        {
            _dbcontext1.demouser.Add(ubadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public demouser EdittRec(int id)
        {
            demouser ub = new demouser();

            return _dbcontext1.demouser.FirstOrDefault(u=>u.Id==id);
            
        }
        public bool UpdateRec(demouser ubupdate)
        {
            var bankrecupdate= _dbcontext1.demouser.FirstOrDefault(u => u.Id == ubupdate.Id);
            if (bankrecupdate != null)
            {
                bankrecupdate.Name = bankrecupdate.Name;
                bankrecupdate.Company = bankrecupdate.Company;
                bankrecupdate.Role = bankrecupdate.Role;
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(demouser ubdel)
        {
            var bankrecdel = _dbcontext1.demouser.FirstOrDefault(u => u.Id == ubdel.Id);
            if (bankrecdel != null)
            {
                bankrecdel.Name = bankrecdel.Name;
                bankrecdel.Company = bankrecdel.Company;
                bankrecdel.Role = bankrecdel.Role;
                
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
