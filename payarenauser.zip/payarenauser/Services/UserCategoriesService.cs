﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class UserCategoriesService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public UserCategoriesService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<UsercategoriesClass> GetAllUsers()
           
        {
            return _dbcontext1.usercategories.ToList();
           
        }

       
        public bool InsertRec(UsercategoriesClass ucadd)
        {
            _dbcontext1.usercategories.Add(ucadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public UsercategoriesClass EdittRec(int usercategoryid)
        {
            UsercategoriesClass uc = new UsercategoriesClass();

            return _dbcontext1.usercategories.FirstOrDefault(u=>u.usercategoryid == usercategoryid);
            
        }
        public bool UpdateRec(UsercategoriesClass ucupdate)
        {
            var userrecupdate= _dbcontext1.usercategories.FirstOrDefault(u => u.usercategoryid == ucupdate.usercategoryid);
            if (userrecupdate != null)
            {
                userrecupdate.usercategory = userrecupdate.usercategory;
                userrecupdate.categoryid = userrecupdate.categoryid;
                
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(UsercategoriesClass ucdel)
        {
            var userrecdel = _dbcontext1.usercategories.FirstOrDefault(u => u.usercategoryid == ucdel.usercategoryid);
            if (userrecdel != null)
            {
                userrecdel.usercategory = userrecdel.usercategory;
                userrecdel.categoryid = userrecdel.categoryid;
                
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
