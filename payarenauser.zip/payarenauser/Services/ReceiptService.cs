﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class ReceiptService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public ReceiptService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<receiptClass> GetAllReceipt()
        {
            return _dbcontext1.receipt.ToList();
        }
        public bool InsertRec(receiptClass ubadd)
        {
            _dbcontext1.receipt.Add(ubadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public receiptClass EdittRec(int Receiptid)
        {
            receiptClass ub = new receiptClass();

            return _dbcontext1.receipt.FirstOrDefault(u=>u.receiptid == Receiptid);
            
        }
        public bool UpdateRec(receiptClass ubupdate)
        {
            var Receiptrecupdate= _dbcontext1.receipt.FirstOrDefault(u => u.receiptid == ubupdate.receiptid);
            if (Receiptrecupdate != null)
            {
                Receiptrecupdate.receiptnos = Receiptrecupdate.receiptnos;
                Receiptrecupdate.customername = Receiptrecupdate.customername;
                Receiptrecupdate.phonenumber = Receiptrecupdate.phonenumber;

                Receiptrecupdate.vendor = Receiptrecupdate.vendor;
                Receiptrecupdate.collections = Receiptrecupdate.collections;
                Receiptrecupdate.transactionamount = Receiptrecupdate.transactionamount;

                Receiptrecupdate.fee = Receiptrecupdate.fee;
                Receiptrecupdate.totalamount = Receiptrecupdate.totalamount;
                Receiptrecupdate.institution = Receiptrecupdate.institution;
                Receiptrecupdate.teller = Receiptrecupdate.teller;

                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(receiptClass ubdel)
        {
            var Receiptrecdel = _dbcontext1.receipt.FirstOrDefault(u => u.receiptid == ubdel.receiptid);
            if (Receiptrecdel != null)
            {
                Receiptrecdel.receiptnos = Receiptrecdel.receiptnos;
                Receiptrecdel.customername = Receiptrecdel.customername;
                Receiptrecdel.phonenumber = Receiptrecdel.phonenumber;

                Receiptrecdel.vendor = Receiptrecdel.vendor;
                Receiptrecdel.collections = Receiptrecdel.collections;
                Receiptrecdel.transactionamount = Receiptrecdel.transactionamount;

                Receiptrecdel.fee = Receiptrecdel.fee;
                Receiptrecdel.totalamount = Receiptrecdel.totalamount;
                Receiptrecdel.institution = Receiptrecdel.institution;
                Receiptrecdel.teller = Receiptrecdel.teller;

                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
