﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class BankService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public BankService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<BankClass> GetAllBanks()
        {
            return _dbcontext1.Bank.ToList();
        }

        public List<BankClass> GetuniqueBank(string bankname)
        {

            return _dbcontext1.Bank.Where(x => x.bankfullname == bankname).ToList();
        }

        public List<BankClass> GetexceptBank(string bankname)
        {

            return _dbcontext1.Bank.Where(x => x.bankfullname != bankname).ToList();
        }

        public bool InsertRec(BankClass ubadd)
        {
            _dbcontext1.Bank.Add(ubadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public BankClass EdittRec(int bankid)
        {
            BankClass ub = new BankClass();

            return _dbcontext1.Bank.FirstOrDefault(u=>u.bankid==bankid);
            
        }
        public bool UpdateRec(BankClass ubupdate)
        {
            var bankrecupdate= _dbcontext1.Bank.FirstOrDefault(u => u.bankid == ubupdate.bankid);
            if (bankrecupdate != null)
            {
                bankrecupdate.bankcode = bankrecupdate.bankcode;
                bankrecupdate.bankabbr = bankrecupdate.bankabbr;
                bankrecupdate.bankfullname = bankrecupdate.bankfullname;
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(BankClass ubdel)
        {
            var bankrecdel = _dbcontext1.Bank.FirstOrDefault(u => u.bankid == ubdel.bankid);
            if (bankrecdel != null)
            {
                bankrecdel.bankcode = bankrecdel.bankcode;
                bankrecdel.bankabbr = bankrecdel.bankabbr;
                bankrecdel.bankfullname = bankrecdel.bankfullname;
                
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
