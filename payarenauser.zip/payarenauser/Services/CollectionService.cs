﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class CollectionService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public CollectionService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<CollectionClass> GetAllcollections()
        {
            return _dbcontext1.collection.ToList();
        }
        public bool InsertRec(CollectionClass ubadd)
        {
            _dbcontext1.collection.Add(ubadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public CollectionClass EdittRec(int collectionid)
        {
            CollectionClass ub = new CollectionClass();

            return _dbcontext1.collection.FirstOrDefault(u=>u.collectionid == collectionid);
            
        }
        public bool UpdateRec(CollectionClass ubupdate)
        {
            var collectionrecupdate= _dbcontext1.collection.FirstOrDefault(u => u.collectionid == ubupdate.collectionid);
            if (collectionrecupdate != null)
            {
                collectionrecupdate.collectioncode = collectionrecupdate.collectioncode;
                collectionrecupdate.vendor = collectionrecupdate.vendor;
                
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(CollectionClass ubdel)
        {
            var collectionrecdel = _dbcontext1.collection.FirstOrDefault(u => u.collectionid == ubdel.collectionid);
            if (collectionrecdel != null)
            {
                collectionrecdel.collectioncode = collectionrecdel.collectioncode;
                collectionrecdel.vendor = collectionrecdel.vendor;
                
                
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
