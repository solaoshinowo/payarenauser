﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using payarenauser.Data;
using Payarenauser.Data;

namespace Payarenauser.Services
{
    public class BankBranchspecificService
    {
        protected readonly ApplicationDbContext1 _dbcontext1;
        public BankBranchspecificService(ApplicationDbContext1 _db)
        {
            _dbcontext1 = _db;
        }
        public List<BankBranchClass> GetAllBanks(string bankname)
        {
           
            return _dbcontext1.bankbranch.Where(x => x.bank == bankname).ToList();
        }
        public bool InsertRec(BankBranchClass ubadd)
        {
            _dbcontext1.bankbranch.Add(ubadd);
            _dbcontext1.SaveChanges();
            return true;
        }

        public BankBranchClass EdittRec(int bankbranchid)
        {
            BankBranchClass ub = new BankBranchClass();

            return _dbcontext1.bankbranch.FirstOrDefault(u=>u.bankbranchid == bankbranchid);
            
        }
        public bool UpdateRec(BankBranchClass ubupdate)
        {
            var bankrecupdate= _dbcontext1.bankbranch.FirstOrDefault(u => u.bankbranchid == ubupdate.bankbranchid);
            if (bankrecupdate != null)
            {
                bankrecupdate.bankbranchcode = bankrecupdate.bankbranchcode;
                bankrecupdate.bankabbr = bankrecupdate.bankabbr;
                bankrecupdate.bankbranch = bankrecupdate.bankbranch;
                bankrecupdate.bank = bankrecupdate.bank;

                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

        public bool delRec(BankBranchClass ubdel)
        {
            var bankrecdel = _dbcontext1.bankbranch.FirstOrDefault(u => u.bankbranchid == ubdel.bankbranchid);
            if (bankrecdel != null)
            {
                bankrecdel.bankbranchcode = bankrecdel.bankbranchcode;
                bankrecdel.bankabbr = bankrecdel.bankabbr;
                bankrecdel.bankbranch = bankrecdel.bankbranch;
                
               
                _dbcontext1.SaveChanges();
            }
            else
            {
                return false;
            }
            return true;
        }

    }
}
